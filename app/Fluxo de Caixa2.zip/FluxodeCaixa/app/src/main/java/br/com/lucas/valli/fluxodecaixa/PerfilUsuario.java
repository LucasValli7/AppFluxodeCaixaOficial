package br.com.lucas.valli.fluxodecaixa;

import static com.google.firebase.messaging.Constants.MessageNotificationKeys.TAG;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import br.com.lucas.valli.fluxodecaixa.databinding.ActivityPerfilUsuarioBinding;

public class PerfilUsuario extends AppCompatActivity {

    private ActivityPerfilUsuarioBinding binding;
    private String usuarioID;
    private Uri mSelecionarUri;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPerfilUsuarioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();
        RecuperarDadosUsuario();
        binding.btnSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelecionarFoto();

            }
        });
        binding.btnAtualizar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String emailAtual = binding.editAtualizarEmail.getText().toString();
                String novoEmail = binding.editNovoEmail.getText().toString();
                String senha = binding.editSenha.getText().toString();

                if (!emailAtual.isEmpty() && !novoEmail.isEmpty() && !senha.isEmpty()) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(PerfilUsuario.this);
                    builder.setTitle("Atenção");
                    builder.setMessage("Deseja realmente alterar o e-mail?");
                    builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            UpdatEmail();

                        }
                    });
                    builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();

                        }
                    });
                    builder.show();
                }else {
                    Snackbar snackbar = Snackbar.make(v, "Preencha todos os campos!", Snackbar.LENGTH_INDEFINITE)
                            .setAction("OK", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                }
                            });
                    snackbar.show();
                }

            }
        });
        binding.editAtualizarNome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(PerfilUsuario.this);
                builder.setTitle("Nome de usuário");

                final  EditText edittext_dialogo = new EditText(PerfilUsuario.this);
                builder.setView(edittext_dialogo);

                builder.setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String dialogo = edittext_dialogo.getText().toString();
                        binding.editAtualizarNome.setText(dialogo);
                        AlterarNomeUsuario();

                    }
                });

                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            }
        });
    }
    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK){
                        Intent dados = result.getData();
                        mSelecionarUri = dados.getData();

                        try {
                            binding.circleUsuarioPerfil.setImageURI(mSelecionarUri);
                            AlterarFotoUsuario();
                        }catch (Exception exception){
                            exception.printStackTrace();

                        }
                    }
                }
            });

    public void UpdatEmail(){

        String emailAtual = binding.editAtualizarEmail.getText().toString();
        String emailNovo = binding.editNovoEmail.getText().toString();
        String senhaAtual = binding.editSenha.getText().toString();
        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        if (email.equals(emailNovo) || !emailAtual.equals(email)){
            Toast.makeText(PerfilUsuario.this, "E-mail ou senha são inválidos", Toast.LENGTH_LONG).show();
        }else {

            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            // Get auth credentials from the user for re-authentication

            AuthCredential credential = EmailAuthProvider
                    .getCredential(emailAtual, senhaAtual); // Current Login Credentials \\
            // Prompt the user to re-provide their sign-in credentials
            user.reauthenticate(credential)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                //Now change your email address \\
                                //----------------Code for Changing Email Address----------\\
                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                user.updateEmail(emailNovo)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Toast.makeText(PerfilUsuario.this, "E-mail alterado com com sucesso", Toast.LENGTH_LONG).show();
                                                    RecuperarDadosUsuario();
                                                    finish();

                                                }
                                            }
                                        });
                            } else {
                                Toast.makeText(PerfilUsuario.this, "E-mail ou senha são inválidos", Toast.LENGTH_LONG).show();
                            }

                        }
                    });
        }
    }
    public void AlterarNomeUsuario(){
        String nome = binding.editAtualizarNome.getText().toString();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String,Object> usuarios = new HashMap<>();
        usuarios.put("nome",nome);

        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db.collection(usuarioID).document("usuario")
                .update("nome",nome).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                binding.progressBar.setVisibility(View.VISIBLE);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        binding.progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(PerfilUsuario.this, "Nome de usuário alterado com sucesso", Toast.LENGTH_LONG).show();
                    }
                },1000);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }
    public void AlterarFotoUsuario(){

        String nomeArquivo = UUID.randomUUID().toString();


        final StorageReference storageReference = FirebaseStorage.getInstance().getReference("/imagens/"+ nomeArquivo);
        storageReference.putFile(mSelecionarUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {

                                String foto = uri.toString();
                                FirebaseFirestore db = FirebaseFirestore.getInstance();

                                Map<String,Object> usuarios = new HashMap<>();
                                usuarios.put("foto",foto);

                                usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                db.collection(usuarioID).document("usuario")
                                        .update("foto", foto).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        binding.progressBar.setVisibility(View.VISIBLE);

                                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                binding.progressBar.setVisibility(View.INVISIBLE);
                                                Toast.makeText(PerfilUsuario.this, "Foto de perfil alterada com sucesso", Toast.LENGTH_LONG).show();
                                            }
                                        },1000);
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });



    }
    public void SelecionarFoto(){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        activityResultLauncher.launch(intent);
    }
    public void RecuperarDadosUsuario(){
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();


        DocumentReference documentReference = db.collection(usuarioID).document("usuario");
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    binding.editAtualizarNome.setText(documentSnapshot.getString("nome"));
                    binding.editAtualizarEmail.setText(email);
                    Glide.with(getApplicationContext()).load(documentSnapshot.getString("foto")).into(binding.circleUsuarioPerfil);

                }

            }
        });

    }
}