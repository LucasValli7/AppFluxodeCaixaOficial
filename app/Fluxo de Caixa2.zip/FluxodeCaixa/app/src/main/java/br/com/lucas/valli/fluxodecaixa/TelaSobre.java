package br.com.lucas.valli.fluxodecaixa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import br.com.lucas.valli.fluxodecaixa.databinding.ActivityTelaSobreBinding;

public class TelaSobre extends AppCompatActivity {

    private ActivityTelaSobreBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivityTelaSobreBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());
        getSupportActionBar().hide();
    }
}